/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
        
        System.out.println("=== Registration ===");
        
        System.out.println("Enter username (must cointain '_' and be <=5 characters):");
        String userName = scanner.nextLine();
        
        System.out.println("Enter a password (8+ characters, capital letter, number, spcial characters): ");
        String password = scanner.nextLine();
        
        System.out.println("Enter your South African cell phone number (e.g. +27838968976):");
        String cellPhoneNumber = scanner.nextLine();
        
        System.out.println("Enter your first name: ");
        String firstName = scanner.nextLine();
        
        System.out.println("Enter your last name: ");
        String lastName = scanner.nextLine();
        
        String registrationResult = login.registerUser(
                userName, password, cellPhoneNumber, firstName, lastName);
        System.out.println(registrationResult);
        
        if (login.getUserName() != null) {
            System.out.println("\n=== Login ===");
            
            System.out.println("Enter your username: ");
            String loginUserName = scanner.nextLine();
            
            System.out.println("Enter your password: ");
            String loginPassword = scanner.nextLine();
            
            boolean loginSuccessful = login.loginUser(loginUserName, loginPassword);
            System.out.println(login.returnsLoginStatus(loginSuccessful));
        }
        scanner.close();
        }
        
        
    
}
