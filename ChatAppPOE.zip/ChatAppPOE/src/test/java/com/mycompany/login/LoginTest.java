/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.login;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
    private Login login;

 @Before
 public void setUp() {
     login = new Login();
    }
 
 @Test
 public void testUserName_CorrectlyFormatted() {
     assertTrue(login.checkUserName("kyl_1"));
     assertEquals("Username successfully captured.", login.captureUserName("kyl_1"));
 }
 
 @Test 
 public void testUserNmae_IncorrectlyFormatted() {
     assertFalse(login.checkUserName("kyle!!!!!!"));
     assertEquals(
             "Username is not correctly formatted; please ensure that your username"
              + "contains an underscore and is no more than five characters in length.",
                login.captureUserName("kyle!!!!!!"));
 }
 
 @Test 
 public void testPassword_MeetsComplexityReqirements() {
     assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
     assertEquals("Password successfully captured.", login.capturePassword("Ch&&sec@ke99!"));
 }
 
 @Test
 public void testPassword_DoesNotMeetComlexityRequirements() {
     assertFalse(login.checkPasswordComplexity("password"));
     assertEquals(
                 "Password is not correctly formatted; please ensure that the password "
                  + "contains at least eight characters, a capital letter, a number, and a"
                  + "special character.",
                   login.capturePassword("password"));
 }
 
 @Test 
 public void testCellPhoneNumber_CorrectlyFormatted() {
     assertTrue(login.checkCellPhoneNumber("+27838968976"));
     assertEquals("Cell number successfully captured.", login.captureCellPhoneNumber("+27838968976"));
 }
 
 @Test
 public void testCellPhoneNumber_IncorrectlyFormatted() {
     assertFalse(login.checkCellPhoneNumber("08966553"));
     assertEquals(
                "Cell number is incorrectly formatted or does not contain an"
                +"international code; please correct the number and try again.",
                 login.captureCellPhoneNumber("08966553"));
 }
 
 @Test
 public void testLogin_Successful() {
     login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
     boolean result = login.loginUser("kyl_1", "Ch&&sec@ke99!");
     assertTrue(result);
     
     String status = login.returnsLoginStatus(result);
     assertEquals("Welcome Kyle, Smith it is great to see you again.", status);
 }
 
 @Test 
 public void testLogin_Failed() {
     login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
     boolean result = login.loginUser("kyl_1", "wrongPassword1!");
     assertFalse(result); 
     
     String status = login.returnsLoginStatus(result);
     assertEquals("Username or password incorrect, please try again.", status);
 }
 
 @Test
 public void testUserNameCorrectlyFormatted_ReturnsTrue() {
     assertTrue(login.checkUserName("kyl_1"));
 }
 
 @Test
 public void testUserNameIncorrectlyFormatted_ReturnsFalse() {
     assertFalse(login.checkUserName("kyle!!!!!!"));
 }
 
 @Test
 public void testPasswordMeetsComplexity_ReturnsTrue() {
     assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
 }
 
 @Test
 public void testPasswordDoesNotMeetComplexity_ReturnsFalse() {
     assertFalse(login.checkPasswordComplexity("password"));
 }
 
 @Test
 public void testCellPhoneCorrectlyFormatted_ReturnsTrue() {
     assertTrue(login.checkCellPhoneNumber("+27838968976"));
 }
 
 @Test
 public void testCellPhoneIncorrectlyFormatted_ReturnsFalse() {
     assertFalse(login.checkCellPhoneNumber("08966553"));
 }

         
     }
     
           
             
        
     
     
     
 
    

