/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.login;

import java.util.regex.Pattern;

/**
 *
 * @author Student
 */
public class Login {
    private String userName;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;
    
    private static final Pattern SPECIAL_CHAR_PATTERN = Pattern.compile("[^A-Za-z0-9]");
    private static final Pattern CAPITAL_LETTER_PATTERN =Pattern.compile("[A-Z]");
    private static final Pattern NUMBER_PATTERN = Pattern.compile("[0-9]");
    
    private static final Pattern CELLPHONE_PATTERN = Pattern.compile("^\\+27\\d{9}$");
    
    public Login(){
    }
        
        public boolean checkUserName(String userName) {
            if (userName == null) {
                return false;
        }
            return userName.contains("_") && userName.length()<= 5;
    }
        public boolean checkPasswordComplexity(String password){
            if (password == null) {
                return false;
            }
            boolean longEnough = password.length() >= 8;
            boolean hasCapital = CAPITAL_LETTER_PATTERN.matcher(password).find();
            boolean hasNumber = NUMBER_PATTERN.matcher(password).find();
            boolean hasSpecial = SPECIAL_CHAR_PATTERN.matcher(password).find();
            return longEnough && hasCapital && hasNumber && hasSpecial; 
        }
        
        public boolean checkCellPhoneNumber(String cellPhoneNumber) {
            if (cellPhoneNumber == null) {
                return false;
            }
            return CELLPHONE_PATTERN.matcher(cellPhoneNumber.trim()).matches();
            
        }
        
        public String captureUserName(String userName) {
            return checkUserName(userName)
                    ? "Username successfully captured."
                    : "Username is not correctly formatted; please ensure that your username"
                    + "contains an underscore and is no more than five characters in length.";
        }
        
        public String capturePassword(String password) {
            return checkPasswordComplexity(password)
                    ? "Password successfully captured."
                    : "Password is not correctly formatted; please ensure that the password contains "
                    + "at least eight characters, a capital letter, a number, and a"
                    + "special character.";
        }
        
        public String captureCellPhoneNumber(String cellPhoneNumber) {
            return checkCellPhoneNumber(cellPhoneNumber)
                    ? "Cell number successfully captured."
                    : "Cell number is incorrectly formatted or does not contain an"
                     +"international code; please correct the number and try again.";
        }
        
        public String registerUser(String userName, String password, String cellPhoneNumber,
                String firstName, String lastName) {
            
            boolean userNameOk = checkUserName(userName);
            boolean passwordOk = checkPasswordComplexity(password);
            boolean cellOk = checkCellPhoneNumber(cellPhoneNumber);
            
            if (!userNameOk) {
                return "Username is not correctly formatted; please ensure that your username "
                        + "contains an underscore and is no more than five characters in length.";
            }
            
            if (!passwordOk) {
                return "Password is not correctly formatted; please ensure that your password "
                        + "contains at least eight characters , a captital letter, a number, and a "
                        + "special character.";
            }
            
            if (!cellOk) {
                return "Cell number is incorrectly formatted or does not contain an "
                        + "international code; please correct the number and try again.";
            }
            
            this.userName = userName;
            this.password = password;
            this.cellPhoneNumber = cellPhoneNumber;
            this.firstName = firstName;
            this.lastName = lastName;
            
            return "Username is successfully captured. Password successfully csptured. "
                    + "Cell number successfully captured. You have been registered successfully.";
        }
        
        public boolean loginUser(String userName, String password) {
            if (userName  == null || password == null || this.userName == null) {
                return false;
            }
            return userName.equals(this.userName) && password.equals(this.password);
        }
        
        public String returnsLoginStatus(boolean loginSuccessful) {
            if (loginSuccessful) {
                return "Welcome Kyle, Smith it is great to see you again.";
                        }
            
            return "Username or password incorrect, please try again.";
                
            }
        
        public String getUserName(){
            return userName;
        }
        
        public String getCellPhoneNumber() {
            return cellPhoneNumber;
        }
        
        public String getFirstName() {
            return firstName ; 
        }
        
        public String getLastName() {
            return  lastName;
        }
            
                    
      
                   
                    
        }
            
    
            

