/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Student
 */
public class MessageTest {

    private Message message1;
    private Message message2; 

    @Before
    public void setUp() {
        message1 = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 0);
        message1.setMessageId("0012345678"); 

        message2 = new Message("08575975889", "Hi Keegan, did you receive the payment?", 0);
        message2.setMessageId("0098765432");
    }


    @Test
    public void testMessageID_NotMoreThanTenCharacters_ReturnsTrue() {
        assertTrue(message1.checkMessageID());
    }

    @Test
    public void testMessageID_MoreThanTenCharacters_ReturnsFalse() {
        message1.setMessageId("12345678901");
        assertFalse(message1.checkMessageID());
    }

   

    @Test
    public void testRecipientCell_CorrectlyFormatted() {
        
        assertEquals("Cell phone number successfully captured.", message1.checkRecipientCell());
    }

    @Test
    public void testRecipientCell_IncorrectlyFormatted() {
    
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an "
            + "international code. Please correct the number and try again.",
            message2.checkRecipientCell()
        );
    }

   

    @Test
    public void testMessageLength_Under250_ReadyToSend() {
        assertTrue(message1.checkMessageLength());
        assertEquals("Message ready to send.", message1.checkMessageLengthResult());
    }

    @Test
    public void testMessageLength_Over250_ReturnsError() {
        StringBuilder longMessage = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            longMessage.append("a");
        }
        Message longMsg = new Message("+27718693002", longMessage.toString(), 0);
        assertFalse(longMsg.checkMessageLength());
        assertEquals(
            "Message exceeds 250 characters by 10; please reduce the size.",
            longMsg.checkMessageLengthResult()
        );
    }

    

    @Test
    public void testCreateMessageHash_MatchesExpectedFormat() {
        
        assertEquals("00:0:HITONIGHT", message1.createMessageHash());
    }

    

    @Test
    public void testSentMessage_Send() {
        assertEquals("Message successfully sent.", message1.sentMessage(1));
    }

    @Test
    public void testSentMessage_Disregard() {
        assertEquals("Press 0 to delete the message.", message2.sentMessage(2));
    }

    @Test
    public void testSentMessage_Store() {
        assertEquals("Message successfully stored.", message1.sentMessage(3));
    }

    

    @Test
    public void testReturnTotalMessagess_IncrementsOnSend() {
        int before = Message.returnTotalMessagess();
        message1.sentMessage(1);
        assertEquals(before + 1, Message.returnTotalMessagess());
    }
}

