/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 *
 * @author Student
 */
public class Message {

    
    private static final Pattern CELLPHONE_PATTERN = Pattern.compile("^\\+27\\d{9}$");

    
    private static final List<Message> sentMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;

    private String messageId;
    private final String recipient;
    private final String messageText;
    private final int messageNumber; 
    private String messageHash;

    public Message(String recipient, String messageText, int messageNumber) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.messageId = generateMessageId();
    }

    
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMessageId() {
        return messageId;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    private String generateMessageId() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    
    public boolean checkMessageID() {
        return messageId != null && messageId.length() <= 10;
    }

    
    private boolean isRecipientCellValid() {
        if (recipient == null) {
            return false;
        }
        return CELLPHONE_PATTERN.matcher(recipient.trim()).matches();
    }

    public String checkRecipientCell() {
        return isRecipientCellValid()
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.";
    }

   
    public boolean checkMessageLength() {
        return messageText != null && messageText.length() <= 250;
    }

    public String checkMessageLengthResult() {
        return checkMessageLength()
                ? "Message ready to send."
                : "Message exceeds 250 characters by "
                + (messageText.length() - 250) + "; please reduce the size.";
    }

    
    public String createMessageHash() {
        String idPrefix = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;

        String[] words = messageText.trim().split("\\s+");
        String firstWord = stripPunctuation(words[0]).toUpperCase();
        String lastWord = stripPunctuation(words[words.length - 1]).toUpperCase();

        this.messageHash = idPrefix + ":" + messageNumber + ":" + firstWord + lastWord;
        return this.messageHash;
    }

    private String stripPunctuation(String word) {
        return word.replaceAll("[^a-zA-Z0-9]", "");
    }

  
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                createMessageHash();
                sentMessages.add(this);
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                createMessageHash();
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageId).append("\n")
              .append("Message Hash: ").append(m.messageHash).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.messageText).append("\n")
              .append("---\n");
        }
        return sb.toString();
    }
    public static int returnTotalMessagess() {
        return totalMessagesSent;
    }

  
    public void storeMessage() {
        List<String> existing = new ArrayList<>();
        java.io.File file = new java.io.File("storedMessages.json");

       
        if (file.exists()) {
            try {
                String content = new String(java.nio.file.Files.readAllBytes(file.toPath()));
                content = content.trim();
                if (content.startsWith("[") && content.endsWith("]") && content.length() > 2) {
                    content = content.substring(1, content.length() - 1);
                    
                    String[] parts = content.split("\\},\\s*\\{");
                    for (String part : parts) {
                        String obj = part;
                        if (!obj.startsWith("{")) {
                            obj = "{" + obj;
                        }
                        if (!obj.endsWith("}")) {
                            obj = obj + "}";
                        }
                        existing.add(obj);
                    }
                }
            } catch (IOException e) {
                
            }
        }

        existing.add(toJson());

        try (FileWriter writer = new FileWriter(file)) {
            writer.write("[\n");
            for (int i = 0; i < existing.size(); i++) {
                writer.write("  " + existing.get(i));
                if (i < existing.size() - 1) {
                    writer.write(",");
                }
                writer.write("\n");
            }
            writer.write("]");
        } catch (IOException e) {
            System.out.println("Could not store message to JSON: " + e.getMessage());
        }
    }

    private String toJson() {
        return "{"
                + "\"messageId\":\"" + escape(messageId) + "\","
                + "\"recipient\":\"" + escape(recipient) + "\","
                + "\"message\":\"" + escape(messageText) + "\""
                + "}";
    }

    private String escape(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}

