/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class QuickChatApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        
        System.out.println("=== Registration ===");
        System.out.print("Enter a username (must contain '_' and be <= 5 characters): ");
        String userName = scanner.nextLine();

        System.out.print("Enter a password (8+ chars, capital letter, number, special char): ");
        String password = scanner.nextLine();

        System.out.print("Enter your South African cell phone number (e.g. +27838968976): ");
        String cellPhoneNumber = scanner.nextLine();

        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        System.out.println(login.registerUser(userName, password, cellPhoneNumber, firstName, lastName));

        if (login.getUserName() == null) {
            System.out.println("Registration failed - cannot continue to login.");
            scanner.close();
            return;
        }

        System.out.println("\n=== Login ===");
        System.out.print("Enter your username: ");
        String loginUserName = scanner.nextLine();
        System.out.print("Enter your password: ");
        String loginPassword = scanner.nextLine();

        boolean loginSuccessful = login.loginUser(loginUserName, loginPassword);
        System.out.println(login.returnsLoginStatus(loginSuccessful));

        if (!loginSuccessful) {
            System.out.println("Login failed - you must log in successfully to send messages.");
            scanner.close();
            return;
        }

        
        System.out.println("\nWelcome to QuickChat.");

        System.out.print("How many messages would you like to send this session? ");
        int numMessages = Integer.parseInt(scanner.nextLine().trim());

        int messagesCreated = 0;

        while (true) {
            System.out.println("\nPlease choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Enter your choice: ");
            String option = scanner.nextLine().trim();

            if (option.equals("3")) {
                break;
            } else if (option.equals("2")) {
                System.out.println("Coming Soon.");
            } else if (option.equals("1")) {
                if (messagesCreated >= numMessages) {
                    System.out.println("You have already entered the maximum number of messages (" + numMessages + ") for this session.");
                    continue;
                }

                System.out.print("Enter the recipient's cell number (e.g. +27718693002): ");
                String recipient = scanner.nextLine();

                System.out.print("Enter your message: ");
                String messageText = scanner.nextLine();

                Message message = new Message(recipient, messageText, messagesCreated);
                messagesCreated++;

                String cellResult = message.checkRecipientCell();
                System.out.println(cellResult);
                if (!message.checkMessageID()) {
                    System.out.println("Message ID is incorrectly formatted.");
                    continue;
                }

                String lengthResult = message.checkMessageLengthResult();
                System.out.println(lengthResult);
                if (!message.checkMessageLength()) {
                    continue;
                }

                System.out.println("\nWhat would you like to do with this message?");
                System.out.println("1) Send Message");
                System.out.println("2) Disregard Message");
                System.out.println("3) Store Message to send later");
                System.out.print("Enter your choice: ");
                int sendChoice = Integer.parseInt(scanner.nextLine().trim());

                System.out.println(message.sentMessage(sendChoice));

                if (sendChoice == 1) {
                    System.out.println("\nFull message details:");
                    System.out.println("Message ID: " + message.getMessageId());
                    System.out.println("Message Hash: " + message.getMessageHash());
                    System.out.println("Recipient: " + message.getRecipient());
                    System.out.println("Message: " + message.getMessageText());
                }
            } else {
                System.out.println("Please enter 1, 2, or 3.");
            }
        }

        System.out.println("\nTotal messages sent: " + Message.returnTotalMessagess());
        System.out.println("\nAll sent messages:");
        System.out.println(Message.printMessages());

        scanner.close();
    }
}

