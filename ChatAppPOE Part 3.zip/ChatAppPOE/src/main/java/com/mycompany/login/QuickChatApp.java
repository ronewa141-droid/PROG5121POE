/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

import java.util.List;
import java.util.Scanner;


public class QuickChatApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        
        System.out.println("=== Registration ===");
        System.out.print("Enter a username (must contain '_' and be <= 5 characters): ");
        String userName = scanner.nextLine();

        System.out.print("Enter a password (8+ chars, capital letter, number, special char): ");
        String password = scanner.nextLine();

        System.out.print("Enter your South African cell phone number (e.g. +27838968976): ");
        String cellPhoneNumber = scanner.nextLine();

        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        System.out.println(login.registerUser(userName, password, cellPhoneNumber, firstName, lastName));

        if (login.getUserName() == null) {
            System.out.println("Registration failed - cannot continue to login.");
            scanner.close();
            return;
        }

        System.out.println("\n=== Login ===");
        System.out.print("Enter your username: ");
        String loginUserName = scanner.nextLine();
        System.out.print("Enter your password: ");
        String loginPassword = scanner.nextLine();

        boolean loginSuccessful = login.loginUser(loginUserName, loginPassword);
        System.out.println(login.returnsLoginStatus(loginSuccessful));

        if (!loginSuccessful) {
            System.out.println("Login failed - you must log in successfully to send messages.");
            scanner.close();
            return;
        }

       
        System.out.println("\nWelcome to QuickChat.");

   
        Message.loadStoredMessages();

        int numMessages = readInt(scanner, "How many messages would you like to enter this session? ");
        int messagesCreated = 0;

        boolean running = true;
        while (running) {
            System.out.println("\nPlease choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Enter your choice: ");
            String option = scanner.nextLine().trim();

            switch (option) {
                case "1":
                    if (messagesCreated >= numMessages) {
                        System.out.println("You have already entered the maximum number of messages ("
                                + numMessages + ") for this session.");
                    } else if (enterMessage(scanner, login, messagesCreated)) {
                        messagesCreated++;
                    }
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    running = false;
                    break;
                case "4":
                    storedMessagesMenu(scanner);
                    break;
                default:
                    System.out.println("Please enter 1, 2, 3 or 4.");
            }
        }

        System.out.println("\nTotal messages sent: " + Message.returnTotalMessagess());
        System.out.println("\nAll sent messages:");
        System.out.println(Message.displaySentReport());

        scanner.close();
    }

    
    private static boolean enterMessage(Scanner scanner, Login login, int messageNumber) {
        System.out.print("Enter the recipient's cell number (e.g. +27718693002): ");
        String recipient = scanner.nextLine().trim();

        System.out.print("Enter your message: ");
        String messageText = scanner.nextLine();

        Message message = new Message(recipient, messageText, messageNumber);
        message.setSender(login.getCellPhoneNumber());

        System.out.println(message.checkRecipientCell());
        if (!message.isRecipientCellValid()) {
            return false;
        }

        if (!message.checkMessageID()) {
            System.out.println("Message ID is incorrectly formatted.");
            return false;
        }
        System.out.println("Message ID generated: " + message.getMessageId());

        System.out.println(message.checkMessageLengthResult());
        if (!message.checkMessageLength()) {
            return false;
        }

        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        int sendChoice = readInt(scanner, "Enter your choice: ");

        System.out.println(message.sentMessage(sendChoice));

        if (sendChoice == 1) {
            System.out.println("\nFull message details:");
            System.out.println("Message ID: " + message.getMessageId());
            System.out.println("Message Hash: " + message.getMessageHash());
            System.out.println("Recipient: " + message.getRecipient());
            System.out.println("Message: " + message.getMessageText());
        }
        return sendChoice >= 1 && sendChoice <= 3;
    }

   
    private static void storedMessagesMenu(Scanner scanner) {
        boolean inMenu = true;
        while (inMenu) {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("a) Display the sender and recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search for a message ID and display the recipient and message");
            System.out.println("d) Search for all the messages stored for a particular recipient");
            System.out.println("e) Delete a message using the message hash");
            System.out.println("f) Display a report of all the stored messages");
            System.out.println("g) Back to the main menu");
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine().trim().toLowerCase();

            switch (choice) {
                case "a":
                    System.out.println(Message.displayStoredSenderAndRecipient());
                    break;
                case "b":
                    System.out.println("Longest stored message: " + Message.longestStoredMessage());
                    break;
                case "c":
                    System.out.print("Enter the message ID: ");
                    Message found = Message.findByMessageId(scanner.nextLine().trim());
                    if (found == null) {
                        System.out.println("Message ID not found.");
                    } else {
                        System.out.println("Recipient: " + found.getRecipient());
                        System.out.println("Message: " + found.getMessageText());
                    }
                    break;
                case "d":
                    System.out.print("Enter the recipient's cell number: ");
                    List<String> results = Message.searchStoredByRecipient(scanner.nextLine().trim());
                    if (results.isEmpty()) {
                        System.out.println("No stored messages found for that recipient.");
                    } else {
                        for (String text : results) {
                            System.out.println("Message: " + text);
                        }
                    }
                    break;
                case "e":
                    System.out.print("Enter the message hash: ");
                    System.out.println(Message.deleteByHash(scanner.nextLine().trim()));
                    break;
                case "f":
                    System.out.println(Message.displayStoredReport());
                    break;
                case "g":
                    inMenu = false;
                    break;
                default:
                    System.out.println("Please enter a letter from a to g.");
            }
        }
    }

   
    private static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }
}
