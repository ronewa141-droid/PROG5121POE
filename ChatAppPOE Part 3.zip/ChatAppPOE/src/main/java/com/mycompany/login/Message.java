/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.regex.Pattern;


public class Message {

    private static final ArrayList<Message> sentMessages = new ArrayList<>();
    private static final ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static final ArrayList<Message> storedMessages = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final ArrayList<String> messageIds = new ArrayList<>();

    private static int totalMessagesSent = 0;

    private static String storageFile = "storedMessages.json";

    private static final Pattern CELLPHONE_PATTERN = Pattern.compile("^\\+27\\d{9}$");
    private static final Random RANDOM = new Random();

    private String messageId;
    private String messageHash;
    private String sender = "";
    private String recipient;
    private String messageText;
    private int messageNumber;


    private Message() {
    }

    public Message(String recipient, String messageText, int messageNumber) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.messageId = generateMessageId();
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }
    
    private String generateMessageId() {
        String id;
        do {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                sb.append(RANDOM.nextInt(10));
            }
            id = sb.toString();
        } while (messageIds.contains(id));
        return id;
    }

    
    public boolean checkMessageID() {
        return messageId != null && messageId.length() <= 10;
    }

   
    public boolean isRecipientCellValid() {
        return recipient != null && CELLPHONE_PATTERN.matcher(recipient.trim()).matches();
    }

    public String checkRecipientCell() {
        return isRecipientCellValid()
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.";
    }

 
    public boolean checkMessageLength() {
        return messageText != null && messageText.length() <= 250;
    }

    public String checkMessageLengthResult() {
        return checkMessageLength()
                ? "Message ready to send."
                : "Message exceeds 250 characters by "
                + (messageText.length() - 250) + "; please reduce the size.";
    }

   
    public String createMessageHash() {
        String idPrefix = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;

        String[] words = messageText.trim().split("\\s+");
        String firstWord = stripPunctuation(words[0]).toUpperCase();
        String lastWord = stripPunctuation(words[words.length - 1]).toUpperCase();

        this.messageHash = idPrefix + ":" + messageNumber + ":" + firstWord + lastWord;
        return this.messageHash;
    }

    private String stripPunctuation(String word) {
        return word.replaceAll("[^a-zA-Z0-9]", "");
    }

    
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                recordHashAndId();
                sentMessages.add(this);
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                recordHashAndId();
                disregardedMessages.add(this);
                return "Press 0 to delete the message.";
            case 3:
                recordHashAndId();
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    private void recordHashAndId() {
        createMessageHash();
        messageHashes.add(messageHash);
        messageIds.add(messageId);
    }

   
    public void storeMessage() {
        if (messageHash == null) {
            createMessageHash();
        }
        storedMessages.add(this);
        saveStoredMessages();
    }

    
    public static void setStorageFile(String path) {
        storageFile = path;
    }

    private static void saveStoredMessages() {
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < storedMessages.size(); i++) {
            json.append(i == 0 ? "\n" : ",\n").append(storedMessages.get(i).toJson());
        }
        json.append(storedMessages.isEmpty() ? "]" : "\n]");
        try {
            Files.write(Paths.get(storageFile), json.toString().getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.out.println("Could not save stored messages: " + e.getMessage());
        }
    }


    public static void loadStoredMessages() {
        Path path = Paths.get(storageFile);
        if (!Files.exists(path)) {
            return;
        }
        try {
            String json = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
            List<Map<String, String>> objects = new JsonReader(json).readArrayOfObjects();
            for (Map<String, String> fields : objects) {
                Message m = fromFields(fields);
                if (m.messageText == null || m.messageId == null || messageIds.contains(m.messageId)) {
                    continue;
                }
                if (m.messageHash == null) {
                    m.createMessageHash(); 
                }
                storedMessages.add(m);
                messageHashes.add(m.messageHash);
                messageIds.add(m.messageId);
            }
        } catch (IOException | IllegalArgumentException e) {
            System.out.println("Could not read stored messages: " + e.getMessage());
        }
    }


    public static List<Message> getSentMessages() {
        return Collections.unmodifiableList(sentMessages);
    }

    public static List<Message> getDisregardedMessages() {
        return Collections.unmodifiableList(disregardedMessages);
    }

    public static List<Message> getStoredMessages() {
        return Collections.unmodifiableList(storedMessages);
    }

    public static List<String> getMessageHashes() {
        return Collections.unmodifiableList(messageHashes);
    }

    public static List<String> getMessageIds() {
        return Collections.unmodifiableList(messageIds);
    }

  
    public static List<String> getSentMessageTexts() {
        List<String> texts = new ArrayList<>();
        for (Message m : sentMessages) {
            texts.add(m.messageText);
        }
        return texts;
    }

  
    public static void clearAll() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIds.clear();
        totalMessagesSent = 0;
    }


   
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageId).append("\n")
              .append("Message Hash: ").append(m.messageHash).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.messageText).append("\n")
              .append("---\n");
        }
        return sb.toString();
    }

    /** Total number of messages sent. */
    public static int returnTotalMessagess() {
        return totalMessagesSent;
    }

    
    public static String displaySentReport() {
        return printMessages();
    }

  
    public static String displayStoredSenderAndRecipient() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Sender: ").append(m.sender)
              .append(" | Recipient: ").append(m.recipient).append("\n");
        }
        return sb.toString();
    }

  
    public static String longestStoredMessage() {
        Message longest = longestIn(storedMessages);
        return longest == null ? "There are no stored messages." : longest.messageText;
    }

  
    public static String longestMessage() {
        List<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(storedMessages);
        all.addAll(disregardedMessages);
        Message longest = longestIn(all);
        return longest == null ? "There are no messages." : longest.messageText;
    }

    private static Message longestIn(List<Message> list) {
        Message longest = null;
        for (Message m : list) {
            if (longest == null || m.messageText.length() > longest.messageText.length()) {
                longest = m;
            }
        }
        return longest;
    }

    
    public static Message findByMessageId(String id) {
        List<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(storedMessages);
        all.addAll(disregardedMessages);
        for (Message m : all) {
            if (m.messageId != null && m.messageId.equals(id)) {
                return m;
            }
        }
        return null;
    }


    public static String searchByMessageId(String id) {
        Message m = findByMessageId(id);
        return m == null ? "Message ID not found." : m.messageText;
    }

   
    public static List<String> searchByRecipient(String recipient) {
        List<String> results = new ArrayList<>();
        for (Message m : sentMessages) {
            if (Objects.equals(recipient, m.recipient)) {
                results.add(m.messageText);
            }
        }
        for (Message m : storedMessages) {
            if (Objects.equals(recipient, m.recipient)) {
                results.add(m.messageText);
            }
        }
        return results;
    }

   
    public static List<String> searchStoredByRecipient(String recipient) {
        List<String> results = new ArrayList<>();
        for (Message m : storedMessages) {
            if (Objects.equals(recipient, m.recipient)) {
                results.add(m.messageText);
            }
        }
        return results;
    }

   
    public static String deleteByHash(String hash) {
        Iterator<Message> it = storedMessages.iterator();
        while (it.hasNext()) {
            Message m = it.next();
            if (hash != null && hash.equalsIgnoreCase(m.messageHash)) {
                it.remove();
                messageHashes.remove(m.messageHash);
                messageIds.remove(m.messageId);
                saveStoredMessages();
                return "Message: \"" + m.messageText + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    
    public static String displayStoredReport() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Message ID: ").append(m.messageId).append("\n")
              .append("Message Hash: ").append(m.messageHash).append("\n")
              .append("Sender: ").append(m.sender).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.messageText).append("\n")
              .append("---\n");
        }
        return sb.toString();
    }

    
    private String toJson() {
        return "  {\n"
                + "    \"messageId\": \"" + escapeJson(messageId) + "\",\n"
                + "    \"messageHash\": \"" + escapeJson(messageHash) + "\",\n"
                + "    \"sender\": \"" + escapeJson(sender) + "\",\n"
                + "    \"recipient\": \"" + escapeJson(recipient) + "\",\n"
                + "    \"message\": \"" + escapeJson(messageText) + "\",\n"
                + "    \"messageNumber\": " + messageNumber + "\n"
                + "  }";
    }

    
    private static String escapeJson(String text) {
        if (text == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            switch (c) {
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

   
    private static Message fromFields(Map<String, String> fields) {
        Message m = new Message();
        m.messageId = fields.get("messageId");
        m.messageHash = fields.get("messageHash");
        m.sender = fields.get("sender") == null ? "" : fields.get("sender");
        m.recipient = fields.get("recipient");
        m.messageText = fields.get("message");
        try {
            String number = fields.get("messageNumber");
            m.messageNumber = number == null ? 0 : Integer.parseInt(number.trim());
        } catch (NumberFormatException e) {
            m.messageNumber = 0;
        }
        return m;
    }

    
    private static final class JsonReader {

        private final String text;
        private int pos = 0;

        JsonReader(String text) {
            this.text = text;
        }

        List<Map<String, String>> readArrayOfObjects() {
            List<Map<String, String>> result = new ArrayList<>();
            skipWhitespace();
            if (atEnd()) {
                return result;
            }
            expect('[');
            skipWhitespace();
            if (peek() == ']') {
                pos++;
                return result;
            }
            while (true) {
                result.add(readObject());
                skipWhitespace();
                char c = next();
                if (c == ']') {
                    return result;
                }
                if (c != ',') {
                    throw error("Expected ',' or ']'");
                }
            }
        }

        private Map<String, String> readObject() {
            Map<String, String> map = new HashMap<>();
            skipWhitespace();
            expect('{');
            skipWhitespace();
            if (peek() == '}') {
                pos++;
                return map;
            }
            while (true) {
                skipWhitespace();
                String key = readString();
                skipWhitespace();
                expect(':');
                skipWhitespace();
                map.put(key, readValue());
                skipWhitespace();
                char c = next();
                if (c == '}') {
                    return map;
                }
                if (c != ',') {
                    throw error("Expected ',' or '}'");
                }
            }
        }

        
        private String readValue() {
            if (peek() == '"') {
                return readString();
            }
            int start = pos;
            while (!atEnd() && ",}] \n\r\t".indexOf(text.charAt(pos)) < 0) {
                pos++;
            }
            String token = text.substring(start, pos);
            return token.equals("null") ? null : token;
        }

        private String readString() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (true) {
                if (atEnd()) {
                    throw error("Unterminated string");
                }
                char c = text.charAt(pos++);
                if (c == '"') {
                    return sb.toString();
                }
                if (c != '\\') {
                    sb.append(c);
                    continue;
                }
                if (atEnd()) {
                    throw error("Unterminated string");
                }
                char e = text.charAt(pos++);
                switch (e) {
                    case '"':
                        sb.append('"');
                        break;
                    case '\\':
                        sb.append('\\');
                        break;
                    case '/':
                        sb.append('/');
                        break;
                    case 'n':
                        sb.append('\n');
                        break;
                    case 'r':
                        sb.append('\r');
                        break;
                    case 't':
                        sb.append('\t');
                        break;
                    case 'b':
                        sb.append('\b');
                        break;
                    case 'f':
                        sb.append('\f');
                        break;
                    case 'u':
                        if (pos + 4 > text.length()) {
                            throw error("Bad \\u escape");
                        }
                        sb.append((char) Integer.parseInt(text.substring(pos, pos + 4), 16));
                        pos += 4;
                        break;
                    default:
                        throw error("Bad escape \\" + e);
                }
            }
        }

        private void skipWhitespace() {
            while (!atEnd() && Character.isWhitespace(text.charAt(pos))) {
                pos++;
            }
        }

        private boolean atEnd() {
            return pos >= text.length();
        }

        private char peek() {
            if (atEnd()) {
                throw error("Unexpected end of file");
            }
            return text.charAt(pos);
        }

        private char next() {
            char c = peek();
            pos++;
            return c;
        }

        private void expect(char expected) {
            if (next() != expected) {
                pos--;
                throw error("Expected '" + expected + "'");
            }
        }

        private IllegalArgumentException error(String message) {
            return new IllegalArgumentException(message + " at position " + pos);
        }
    }
}
