/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author Student
 */
import java.io.File;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;


public class StoredMessagesTest {

    private static final String LONG_TEXT = "Where are you? You are late! I have asked you to be on time.";

    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    private Message m1;
    private Message m2;
    private Message m3;
    private Message m4;
    private Message m5;

    private Message make(String id, String recipient, String text, int number) {
        Message m = new Message(recipient, text, number);
        m.setMessageId(id);
        m.setSender("+27838968976");
        return m;
    }

    @Before
    public void setUp() {
        Message.clearAll();
        Message.setStorageFile(new File(tmp.getRoot(), "storedMessages.json").getAbsolutePath());

        m1 = make("0000000001", "+27834557896", "Did you get the cake?", 0);
        m2 = make("0000000002", "+27838884567", LONG_TEXT, 1);
        m3 = make("0000000003", "+27834484567", "Yohoooo, I am at your gate.", 2);
        m4 = make("0838884567", "+27711112222", "It is dinner time!", 3);
        m5 = make("0000000005", "+27838884567", "Ok, I am leaving without you.", 4);

        m1.sentMessage(1); 
        m2.sentMessage(3);
        m3.sentMessage(2); 
        m4.sentMessage(1); 
        m5.sentMessage(3); 
    }

    

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        assertEquals(
            Arrays.asList("Did you get the cake?", "It is dinner time!"),
            Message.getSentMessageTexts()
        );
    }

    @Test
    public void testDisplayTheLongestMessage() {
        assertEquals(LONG_TEXT, Message.longestMessage());
    }

    @Test
    public void testSearchForMessageID() {
        assertEquals("It is dinner time!", Message.searchByMessageId("0838884567"));
    }

    @Test
    public void testSearchForMessageID_NotFound() {
        assertEquals("Message ID not found.", Message.searchByMessageId("9999999999"));
    }

    @Test
    public void testSearchAllMessagesForAParticularRecipient() {
        assertEquals(
            Arrays.asList(LONG_TEXT, "Ok, I am leaving without you."),
            Message.searchByRecipient("+27838884567")
        );
    }

    @Test
    public void testDeleteAMessageUsingTheMessageHash() {
        String hash = m2.getMessageHash();
        assertEquals(
            "Message: \"" + LONG_TEXT + "\" successfully deleted.",
            Message.deleteByHash(hash)
        );
        
        assertEquals("Message hash not found.", Message.deleteByHash(hash));
        assertEquals(1, Message.getStoredMessages().size());
    }

    @Test
    public void testDisplayReport() {
        String report = Message.displaySentReport();
        assertTrue(report.contains(m1.getMessageHash()));
        assertTrue(report.contains("+27834557896"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains(m4.getMessageHash()));
        assertTrue(report.contains("It is dinner time!"));
        
        assertFalse(report.contains("Yohoooo"));
    }

    

    @Test
    public void testDisregardedMessagesArray() {
        assertEquals(1, Message.getDisregardedMessages().size());
        assertEquals("Yohoooo, I am at your gate.", Message.getDisregardedMessages().get(0).getMessageText());
    }

    @Test
    public void testStoredMessagesArray() {
        assertEquals(2, Message.getStoredMessages().size());
        assertEquals(LONG_TEXT, Message.getStoredMessages().get(0).getMessageText());
    }

    @Test
    public void testMessageHashAndIdArrays() {
        assertEquals(5, Message.getMessageHashes().size());
        assertEquals(5, Message.getMessageIds().size());
        assertTrue(Message.getMessageIds().contains("0838884567"));
        assertTrue(Message.getMessageHashes().contains(m2.getMessageHash()));
    }

    

    @Test
    public void testDisplaySenderAndRecipientOfStoredMessages() {
        String output = Message.displayStoredSenderAndRecipient();
        assertTrue(output.contains("Sender: +27838968976"));
        assertTrue(output.contains("Recipient: +27838884567"));
    }

    @Test
    public void testLongestStoredMessage() {
        assertEquals(LONG_TEXT, Message.longestStoredMessage());
    }

    @Test
    public void testSearchStoredByRecipient() {
        List<String> results = Message.searchStoredByRecipient("+27838884567");
        assertEquals(2, results.size());
        assertTrue(Message.searchStoredByRecipient("+27834557896").isEmpty()); // message 1 was only sent
    }

    @Test
    public void testStoredReportHasFullDetails() {
        String report = Message.displayStoredReport();
        assertTrue(report.contains(m2.getMessageId()));
        assertTrue(report.contains(m2.getMessageHash()));
        assertTrue(report.contains("Sender: +27838968976"));
        assertTrue(report.contains("Recipient: +27838884567"));
        assertTrue(report.contains(LONG_TEXT));
    }

  

    @Test
    public void testStoredMessagesAreReadBackFromJson() {
        Message.clearAll();             
        assertEquals(0, Message.getStoredMessages().size());

        Message.loadStoredMessages();    

        assertEquals(2, Message.getStoredMessages().size());
        assertEquals(LONG_TEXT, Message.getStoredMessages().get(0).getMessageText());
        assertEquals("Ok, I am leaving without you.", Message.getStoredMessages().get(1).getMessageText());
        assertEquals("+27838968976", Message.getStoredMessages().get(0).getSender());
    }

    @Test
    public void testDeletedMessageStaysDeletedInJson() {
        Message.deleteByHash(m2.getMessageHash());
        Message.clearAll();
        Message.loadStoredMessages();
        assertEquals(1, Message.getStoredMessages().size());
        assertEquals("Ok, I am leaving without you.", Message.getStoredMessages().get(0).getMessageText());
    }
}

